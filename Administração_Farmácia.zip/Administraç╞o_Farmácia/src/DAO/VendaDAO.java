/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Venda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabri
 */
public class VendaDAO {
    
    public VendaDAO(){        
    }   
    
    public boolean inserirVenda(Model_Venda v){
        
        try {
            String SQL="INSERT INTO gabriel_vaz_farmacia.venda(id_venda,tipo_venda, nome_venda,data_venda,valor_venda) VALUES(?,?,?,?,?)";
            
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,v.getId_venda());
            comando.setString(2,v.getTipo_venda());
            comando.setString(3,v.getNome_venda());
            comando.setString(4,v.getData_venda());
            comando.setFloat(5,v.getValor_venda());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private Model_Venda pegaDados(ResultSet resultado){
        
        try {
            Model_Venda atual = new Model_Venda();
            
            atual.setId_venda(resultado.getInt("id_venda"));
            atual.setTipo_venda(resultado.getString("tipo_venda"));
            atual.setNome_venda(resultado.getString("nome_venda"));
            atual.setData_venda(resultado.getString("data_venda"));
            atual.setValor_venda(resultado.getFloat("valor_venda"));
            
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null; 
    }
    
    public List<Model_Venda> listarVendasCadastradas(){
        try {
            Connection c = Conexao.getConexao();
            String SQL = "SELECT id_venda, tipo_venda, nome_venda, data_venda, valor_venda FROM gabriel_vaz_farmacia.venda ORDER BY id_venda";
            List<Model_Venda> listaDeVendas = new ArrayList<Model_Venda>();
            
            PreparedStatement ps =c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Venda atual = new Model_Venda();
                atual = this.pegaDados(resultado);
                listaDeVendas.add(atual);
            }
            
            return listaDeVendas;
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public Model_Venda consultaVendas(String id_venda){
        
        try {
            String SQL = "SELECT id_venda, tipo_venda, nome_venda, data_venda, valor_venda FROM gabriel_vaz_farmacia.venda WHERE id_venda = ?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps =c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(id_venda));
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Venda atual = new Model_Venda();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean atualizaDadosVenda(Model_Venda dados){
        try {
            String SQL="UPDATE gabriel_vaz_farmacia.venda SET tipo_venda=?,nome_venda=?,data_venda=?,valor_venda=? WHERE id_venda = ?";
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(6,dados.getId_venda());
            comando.setString(1,dados.getTipo_venda());
            comando.setString(2,dados.getNome_venda());
            comando.setString(3,dados.getData_venda());
            comando.setFloat(4,dados.getValor_venda());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Model_Venda consulta(Model_Venda dados){
        try {
            String SQL = "SELECT id_venda, tipo_venda, nome_nome, data_venda, valor_venda FROM gabriel_vaz_farmacia.venda";
            String filtro = "";
            Connection c = Conexao.getConexao();
            
            if(dados != null && dados.getId_venda()>0){
                filtro = "WHERE id_venda = "+dados.getId_venda();
            }
            
            if(dados != null && dados.getTipo_venda()!=null && !dados.getTipo_venda().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND tipo_venda ilike '%"+dados.getTipo_venda()+"%'";
                }else{
                    filtro = "WHERE tipo_venda ilike '%"+dados.getTipo_venda()+"%'";
                }
            }
            
            if(dados != null && dados.getNome_venda()!=null && !dados.getNome_venda().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND nome_venda ilike '%"+dados.getNome_venda()+"%'";
                }else{
                    filtro = "WHERE nome_venda ilike '%"+dados.getNome_venda()+"%'";
                }
            }
            
            if(dados != null && dados.getData_venda()!=null && !dados.getData_venda().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND data_venda ilike '%"+dados.getData_venda()+"%'";
                }else{
                    filtro = "WHERE data_venda ilike '%"+dados.getData_venda()+"%'";
                }
            }
            
            if(dados != null && dados.getValor_venda()>0.00){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND valor_venda = "+dados.getValor_venda();
                }else{
                    filtro = "WHERE valor_venda  = "+dados.getValor_venda();
                }
            }
            
            PreparedStatement ps =c.prepareStatement(SQL + filtro);
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Venda atual = new Model_Venda();
                atual = this.pegaDados(resultado);
                return atual;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
