/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Despesa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabri
 */
public class DespesaDAO {
    
    public DespesaDAO(){
        }
    
    public boolean inserirDespesa(Model_Despesa d){
        
        try {
            String SQL="INSERT INTO gabriel_vaz_farmacia.despesa(id_despesa,tipo_despesa, nome_despesa,data_despesa,valor_despesa) VALUES(?,?,?,?,?)";
            
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,d.getId_despesa());
            comando.setString(2,d.getTipo_despesa());
            comando.setString(3,d.getNome_despesa());
            comando.setString(4,d.getData_despesa());
            comando.setFloat(5,d.getValor_despesa());
            
            int retorno = comando.executeUpdate();
            
             if (retorno>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DespesaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private Model_Despesa pegaDados(ResultSet resultado){
        try {
            Model_Despesa atual = new Model_Despesa();
            
            atual.setId_despesa(resultado.getInt("id_despesa"));
            atual.setTipo_despesa(resultado.getString("tipo_despesa"));
            atual.setNome_despesa(resultado.getString("nome_despesa"));
            atual.setData_despesa(resultado.getString("data_despesa"));
            atual.setValor_despesa(resultado.getFloat("valor_despesa"));
            
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(DespesaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
        
    public List<Model_Despesa> listarDespesasCadastradas(){
        try {
            Connection c = Conexao.getConexao();
            String SQL = "SELECT id_despesa, tipo_despesa, nome_despesa, data_despesa, valor_despesa FROM gabriel_vaz_farmacia.despesa ORDER BY id_despesa";
            List<Model_Despesa> listaDeDespesas = new ArrayList<Model_Despesa>();
            
            PreparedStatement ps =c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Despesa atual = new Model_Despesa();
                atual = this.pegaDados(resultado);
                listaDeDespesas.add(atual);
            }
            
            return listaDeDespesas;
        } catch (SQLException ex) {
            Logger.getLogger(DespesaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
     
    public Model_Despesa ConsultaDespesas(String id_despesa){
        
        try {
            String SQL = "SELECT id_despesa, tipo_despesa, nome_despesa, data_despesa, valor_despesa FROM gabriel_vaz_farmacia.despesa WHERE id_despesa = ?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps =c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(id_despesa));
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Despesa atual = new Model_Despesa();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(DespesaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean atualizaDadosDespesa(Model_Despesa dados){
        try {
            String SQL="UPDATE gabriel_vaz_farmacia.despesa SET tipo_despesa=?,nome_despesa=?,data_despesa=?,valor_despesa=? WHERE id_despesa = ?";
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(6,dados.getId_despesa());
            comando.setString(1,dados.getTipo_despesa());
            comando.setString(2,dados.getNome_despesa());
            comando.setString(3,dados.getData_despesa());
            comando.setFloat(4,dados.getValor_despesa());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DespesaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        return false;   

    }
    
    public Model_Despesa consulta(Model_Despesa dados){
        
        try {
            String SQL = "SELECT id_despesa, tipo_despesa, nome_despesa, data_despesa, valor_despesa FROM gabriel_vaz_farmacia.despesa";
            String filtro = "";
            Connection c = Conexao.getConexao();
            
            if(dados != null && dados.getId_despesa()>0){
                filtro = "WHERE id_despesa = "+dados.getId_despesa();
            }
            
            if(dados != null && dados.getTipo_despesa()!=null && !dados.getTipo_despesa().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND tipo_despesa ilike '%"+dados.getTipo_despesa()+"%'";
                }else{
                    filtro = "WHERE tipo_despesa ilike '%"+dados.getTipo_despesa()+"%'";
                }
            }
            
            if(dados != null && dados.getNome_despesa()!=null && !dados.getNome_despesa().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND nome_despesa ilike '%"+dados.getNome_despesa()+"%'";
                }else{
                    filtro = "WHERE nome_despesa ilike '%"+dados.getNome_despesa()+"%'";
                }
            }
            
            if(dados != null && dados.getData_despesa()!=null && !dados.getData_despesa().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND data_despesa ilike '%"+dados.getData_despesa()+"%'";
                }else{
                    filtro = "WHERE data_despesa ilike '%"+dados.getData_despesa()+"%'";
                }
            }
            
            if(dados != null && dados.getValor_despesa()>0.00){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND valor_despesa = "+dados.getValor_despesa();
                }else{
                    filtro = "WHERE valor_despesa  = "+dados.getValor_despesa();
                }
            }
            
            PreparedStatement ps =c.prepareStatement(SQL + filtro);
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Despesa atual = new Model_Despesa();
                atual = this.pegaDados(resultado);
                return atual;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(DespesaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
}
