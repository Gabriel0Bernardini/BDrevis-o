/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabri
 */
public class ClienteDAO {
    
    public ClienteDAO(){
    }
    
    public boolean inserirCliente(Model_Cliente c){
            
        try {
            String SQL="INSERT INTO gabriel_vaz_farmacia.cliente(id_cliente,nome_cliente, cpf,email,telefone,endereco) VALUES(?,?,?,?,?,?)";
            
            Connection minhaConexao = Conexao.getConexao();
        
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,c.getId_cliente());
            comando.setString(2,c.getNome_cliente());
            comando.setString(3,c.getCpf());
            comando.setString(4,c.getEmail());
            comando.setString(5,c.getTelefone());
            comando.setString(6,c.getEndereco());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private Model_Cliente pegaDados(ResultSet resultado){
        
        try {
            Model_Cliente atual = new Model_Cliente();
            
            atual.setId_cliente(resultado.getInt("id_cliente"));
            atual.setNome_cliente(resultado.getString("nome_cliente"));
            atual.setCpf(resultado.getString("cpf"));
            atual.setEmail(resultado.getString("email"));
            atual.setTelefone(resultado.getString("telefone"));
            atual.setEndereco(resultado.getString("endereco"));
            
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public List<Model_Cliente> listarClientesCadastrados() {
        
        try {
            Connection c = Conexao.getConexao();
            String SQL = "SELECT id_cliente, nome_cliente, cpf, email, telefone, endereco FROM gabriel_vaz_farmacia.cliente ORDER BY id_cliente";
            List<Model_Cliente> listaDeClientes = new ArrayList<Model_Cliente>();
            
            PreparedStatement ps =c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Cliente atual = new Model_Cliente();
                atual = this.pegaDados(resultado);
                listaDeClientes.add(atual);
            }
            
            return listaDeClientes;
            
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }
    
    public Model_Cliente consultaClientes(String id_cliente){
        
        try {
            String SQL = "SELECT id_cliente, nome_cliente, cpf, email, telefone, endereco FROM gabriel_vaz_farmacia.cliente WHERE id_cliente = ?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps =c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(id_cliente));
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Cliente atual = new Model_Cliente();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
        
    public boolean atualizaDadosCliente(Model_Cliente dados){
        
        try {
            String SQL="UPDATE gabriel_vaz_farmacia.cliente SET nome_cliente=?,cpf=?,email=?,telefone=?,endereco=? WHERE id_cliente = ?";
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(6,dados.getId_cliente());
            comando.setString(1,dados.getNome_cliente());
            comando.setString(2,dados.getCpf());
            comando.setString(3,dados.getEmail());
            comando.setString(4,dados.getTelefone());
            comando.setString(5,dados.getEndereco());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Model_Cliente consulta(Model_Cliente dados){
        
        try {
            String SQL = "SELECT id_cliente, nome_cliente, cpf, email, telefone, endereco FROM gabriel_vaz_farmacia.cliente ";
            String filtro = "";
            Connection c = Conexao.getConexao();
            
            if(dados != null && dados.getId_cliente()>0){
                filtro = "WHERE id_cliente = "+dados.getId_cliente();
            }
            
            if(dados != null && dados.getNome_cliente()!=null && !dados.getNome_cliente().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND nome_cliente ilike '%"+dados.getNome_cliente()+"%'";
                }else{
                    filtro = "WHERE nome_cliente ilike '%"+dados.getNome_cliente()+"%'";
                }
            }
            
            if(dados != null && dados.getCpf()!=null && !dados.getCpf().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND cpf ilike '%"+dados.getCpf()+"%'";
                }else{
                    filtro = "WHERE cpf ilike '%"+dados.getCpf()+"%'";
                }  
            }
            
            if(dados != null && dados.getEmail()!=null && !dados.getEmail().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND email ilike '%"+dados.getEmail()+"%'";
                }else{
                    filtro = "WHERE email ilike '%"+dados.getEmail()+"%'";
                }
            }
            
            if(dados != null && dados.getTelefone()!=null && !dados.getTelefone().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND telefone ilike '"+dados.getTelefone()+"'";
                }else{
                    filtro = "WHERE telefone ilike '"+dados.getTelefone()+"'";
                }
            }
            
            if(dados != null && dados.getEndereco()!=null && !dados.getEndereco().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND endereco ilike '%"+dados.getEndereco()+"%'";
                }else{
                    filtro = "WHERE endereco ilike '%"+dados.getEndereco()+"%'";
                }
            }
            
            PreparedStatement ps =c.prepareStatement(SQL + filtro);
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Cliente atual = new Model_Cliente();
                atual = this.pegaDados(resultado);
                return atual;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
