/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabri
 */
public class ProdutoDAO {
    
    public ProdutoDAO(){
    }
    
    public boolean inserirProduto(Model_Produto p){
        
        try {
            String SQL="INSERT INTO gabriel_vaz_farmacia.produto(id_produto,quantidade, preco,balcao_ou_prateleira,"
                    + "nome_produto,desc_produto,tipo_produto) VALUES(?,?,?,?,?,?,?)";
            
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,p.getId_produto());
            comando.setInt(2,p.getQuantidade());
            comando.setFloat(3,p.getPreco());
            comando.setString(4,p.getBalcao_ou_prateleira());
            comando.setString(5,p.getNome_produto());
            comando.setString(6,p.getDesc_produto());
            comando.setString(7,p.getTipo_produto());
            
            int retorno = comando.executeUpdate();
            
             if (retorno>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
       
    private Model_Produto pegaDados(ResultSet resultado){
        try {
            Model_Produto atual = new Model_Produto();
            
            atual.setId_produto(resultado.getInt("id_produto"));
            atual.setQuantidade(resultado.getInt("quantidade"));
            atual.setPreco(resultado.getFloat("preco"));
            atual.setBalcao_ou_prateleira(resultado.getString("balcao_ou_prateleira"));
            atual.setNome_produto(resultado.getString("nome_produto"));
            atual.setDesc_produto(resultado.getString("desc_produto"));
            atual.setTipo_produto(resultado.getString("tipo_produto"));
            
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public List<Model_Produto> listarProdutosCadastrados(){
        
        try {
            Connection c = Conexao.getConexao();
            String SQL = "SELECT id_produto, quantidade, preco, balcao_ou_prateleira, nome_produto, desc_produto,tipo_produto FROM gabriel_vaz_farmacia.produto ORDER BY id_produto";
            List<Model_Produto> listaDeProdutos = new ArrayList<Model_Produto>();
            
            PreparedStatement ps =c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Produto atual = new Model_Produto();
                atual = this.pegaDados(resultado);
                listaDeProdutos.add(atual);
            }
            
            return listaDeProdutos;
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public Model_Produto consultaProdutos(String id_produto){
        try {
            String SQL = "SELECT id_produto, quantidade, preco, balcao_ou_prateleira, nome_produto, desc_produto, tipo_produto FROM gabriel_vaz_farmacia.produto WHERE id_produto = ?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps =c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(id_produto));
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Produto atual = new Model_Produto();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean atualizaDadosProduto(Model_Produto dados){
        try {
            String SQL="UPDATE gabriel_vaz_farmacia.produto SET quantidade=?,preco=?,balcao_ou_prateleira=?,nome_produto=?, desc_produto=?, tipo_produto=? WHERE id_produto = ?";
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(7,dados.getId_produto());
            comando.setInt(1,dados.getQuantidade());
            comando.setFloat(2,dados.getPreco());
            comando.setString(3,dados.getBalcao_ou_prateleira());
            comando.setString(4,dados.getNome_produto());
            comando.setString(5,dados.getDesc_produto());
            comando.setString(6,dados.getTipo_produto());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Model_Produto consulta(Model_Produto dados){
        try {
            String SQL = "SELECT id_produto, quantidade, preco, balcao_ou_prateleira, nome_produto, desc_produto, tipo_produto FROM gabriel_vaz_farmacia.produto";
            String filtro = "";
            Connection c = Conexao.getConexao();
            
            if(dados != null && dados.getId_produto()>0){
                filtro = "WHERE id_venda = "+dados.getId_produto();
            }
            
            if(dados != null && dados.getQuantidade()>0){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND quantidade = "+dados.getQuantidade();
                }else{
                    filtro = "WHERE quantidade  = "+dados.getQuantidade();
                }
            }
            
            if(dados != null && dados.getPreco()>0.00){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND preco = "+dados.getPreco();
                }else{
                    filtro = "WHERE preco  = "+dados.getPreco();
                }
            }
            
            if(dados != null && dados.getBalcao_ou_prateleira()!=null && !dados.getBalcao_ou_prateleira().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND balcao_ou_prateleira ilike '%"+dados.getBalcao_ou_prateleira()+"%'";
                }else{
                    filtro = "WHERE balcao_ou_prateleira ilike '%"+dados.getBalcao_ou_prateleira()+"%'";
                }
            }
            
            if(dados != null && dados.getNome_produto()!=null && !dados.getNome_produto().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND nome_produto ilike '%"+dados.getNome_produto()+"%'";
                }else{
                    filtro = "WHERE nome_produto ilike '%"+dados.getNome_produto()+"%'";
                }
            }
            
            if(dados != null && dados.getDesc_produto()!=null && !dados.getDesc_produto().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND desc_produto ilike '%"+dados.getDesc_produto()+"%'";
                }else{
                    filtro = "WHERE desc_produto ilike '%"+dados.getDesc_produto()+"%'";
                }
            }
            
            if(dados != null && dados.getTipo_produto()!=null && !dados.getTipo_produto().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND tipo_produto ilike '%"+dados.getTipo_produto()+"%'";
                }else{
                    filtro = "WHERE tipo_produto ilike '%"+dados.getTipo_produto()+"%'";
                }
            }
            
            PreparedStatement ps =c.prepareStatement(SQL + filtro);
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Produto atual = new Model_Produto();
                atual = this.pegaDados(resultado);
                return atual;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
            
    
}
