/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;


/**
 *
 * @author gabri
 */
public class Model_Despesa {
    private int id_despesa;
    private String tipo_despesa, nome_despesa,data_despesa;
    private float valor_despesa;

    public Model_Despesa(int id_despesa, String tipo_despesa, String nome_despesa, String data_despesa, float valor_despesa) {
        this.id_despesa = id_despesa;
        this.tipo_despesa = tipo_despesa;
        this.nome_despesa = nome_despesa;
        this.data_despesa = data_despesa;
        this.valor_despesa = valor_despesa;
    }
  

    
    public Model_Despesa() {
        this.id_despesa = 0;
        this.tipo_despesa = "";
        this.nome_despesa = "";
        this.valor_despesa = 0;
        this.data_despesa = "" ;
    }

    public int getId_despesa() {
        return id_despesa;
    }

    public void setId_despesa(int id_despesa) {
        this.id_despesa = id_despesa;
    }
    
    
    
    public String getTipo_despesa() {
        return tipo_despesa;
    }

    public void setTipo_despesa(String tipo_despesa) {
        this.tipo_despesa = tipo_despesa;
    }

    public String getNome_despesa() {
        return nome_despesa;
    }

    public void setNome_despesa(String nome_despesa) {
        this.nome_despesa = nome_despesa;
    }

    public String getData_despesa() {
        return data_despesa;
    }

    public void setData_despesa(String data_despesa) {
        this.data_despesa = data_despesa;
    }

    public float getValor_despesa() {
        return valor_despesa;
    }

    public void setValor_despesa(float valor_despesa) {
        this.valor_despesa = valor_despesa;
    }

    @Override
    public String toString() {
        return "Model_Despesa{" + "id_despesa=" + id_despesa + ", tipo_despesa=" + tipo_despesa + ", nome_despesa=" + nome_despesa + ", data_despesa=" + data_despesa + ", valor_despesa=" + valor_despesa + '}';
    }

      
    
}
