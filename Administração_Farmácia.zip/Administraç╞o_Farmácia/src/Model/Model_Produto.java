/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author gabri
 */
public class Model_Produto {
    private int id_produto, quantidade;
    private float preco;
    private String balcao_ou_prateleira, nome_produto,desc_produto,tipo_produto;

    public Model_Produto(int id_produto, int quantidade, float preco, String balcao_ou_prateleira, String nome_produto, String desc_produto, String tipo_produto) {
        this.id_produto = id_produto;
        this.quantidade = quantidade;
        this.preco = preco;
        this.balcao_ou_prateleira = balcao_ou_prateleira;
        this.nome_produto = nome_produto;
        this.desc_produto = desc_produto;
        this.tipo_produto = tipo_produto;
    }

    
    public Model_Produto() {
        this.id_produto = 0;
        this.quantidade = 0;
        this.preco = 0;
        this.balcao_ou_prateleira = "";
        this.nome_produto = "";
        this.desc_produto="";
        this.tipo_produto="";
    }

    public int getId_produto() {
        return id_produto;
    }

    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getBalcao_ou_prateleira() {
        return balcao_ou_prateleira;
    }

    public void setBalcao_ou_prateleira(String balcao_ou_prateleira) {
        this.balcao_ou_prateleira = balcao_ou_prateleira;
    }

    public String getNome_produto() {
        return nome_produto;
    }

    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    public String getDesc_produto() {
        return desc_produto;
    }

    public void setDesc_produto(String desc_produto) {
        this.desc_produto = desc_produto;
    }

    public String getTipo_produto() {
        return tipo_produto;
    }

    public void setTipo_produto(String tipo_produto) {
        this.tipo_produto = tipo_produto;
    }

    @Override
    public String toString() {
        return "Model_Produto{" + "id_produto=" + id_produto + ", quantidade=" + quantidade + ", preco=" + preco + ", balcao_ou_prateleira=" + balcao_ou_prateleira + ", nome_produto=" + nome_produto + ", desc_produto=" + desc_produto + ", tipo_produto=" + tipo_produto + '}';
    }
     
    
}
