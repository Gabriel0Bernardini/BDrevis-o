/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author gabri
 */
public class Model_Venda {
    private int id_venda;
    private String tipo_venda, nome_venda,data_venda;
    private float valor_venda;

    public Model_Venda(int id_venda, String tipo_venda, String nome_venda, String data_venda, float valor_venda) {
        this.id_venda = id_venda;
        this.tipo_venda = tipo_venda;
        this.nome_venda = nome_venda;
        this.data_venda = data_venda;
        this.valor_venda = valor_venda;
    }

    

    public Model_Venda() {
        this.id_venda = 0;
        this.tipo_venda = "";
        this.nome_venda = "";
        this.data_venda = "";
        this.valor_venda = 0;
    }

    public int getId_venda() {
        return id_venda;
    }

    public void setId_venda(int id_venda) {
        this.id_venda = id_venda;
    }
    
    
    
    public String getTipo_venda() {
        return tipo_venda;
    }

    public void setTipo_venda(String tipo_venda) {
        this.tipo_venda = tipo_venda;
    }

    public String getNome_venda() {
        return nome_venda;
    }

    public void setNome_venda(String nome_venda) {
        this.nome_venda = nome_venda;
    }

    public String getData_venda() {
        return data_venda;
    }

    public void setData_venda(String data_venda) {
        this.data_venda = data_venda;
    }

    public float getValor_venda() {
        return valor_venda;
    }

    public void setValor_venda(float valor_venda) {
        this.valor_venda = valor_venda;
    }

    @Override
    public String toString() {
        return "Model_Venda{" + "id_venda=" + id_venda + ", tipo_venda=" + tipo_venda + ", nome_venda=" + nome_venda + ", data_venda=" + data_venda + ", valor_venda=" + valor_venda + '}';
    }

}
